% this function runs all test cases in test\functional folder
function run_functional_test()
	functions = functions_with_exact_derivatives; TOL = 1e-15;
	for idx = 1:size(functions,1)
		compute_and_assert(functions{idx,1},functions{idx,2},functions{idx,3},functions{idx,4},TOL);
	end
end

function compute_and_assert(x,fun,fun_J,fun_H,TOL)
	Param.xDim = numel(x);
	z = feval(fun,x,Param);
	Param.zDim = numel(z);
	J = feval(fun_J,x,Param);
	
	[zfwd,Jfwd] = jacobian_fwd(fun,x,Param);
	assert(max(abs(z-zfwd))/max(abs(z)) < TOL,['inconsistent z value of forward mode' func2str(fun)]);
	assert(max(max(abs(J-Jfwd)))/max(max(abs(J))) < TOL,['inconsistent Jacobian of forward mode' func2str(fun)]);
	
	[zrev,Jrev] = jacobian_rev(fun,x,Param);
	assert(max(abs(z-zrev))/max(abs(z)) < TOL,['inconsistent z value of reverse mode' func2str(fun)]);
	assert(max(max(abs(J-Jrev)))/max(abs(J(:))) < TOL,['inconsistent Jacobian of reverse mode' func2str(fun)]);
	
	if(~isempty(fun_H))
		H = feval(fun_H,x,Param);
		[zad,gad,Had] = hessian_ad(fun,x,Param);
		assert(max(abs(z-zad))/max(abs(z)) < TOL,['inconsistent z value of Hessian mode' func2str(fun)]);
		assert(max(abs(J-gad))/max(abs(J)) < TOL,['inconsistent gradient of Hessian mode' func2str(fun)]);
		assert(max(max(abs(H-Had)))/max(abs(H(:))) < TOL,['inconsistent Hessian of Hessian mode' func2str(fun)]);
	end
end

% get first derivatives uinsg foward mode
function [z,J] = jacobian_fwd(fun,x,Param)
	options = setopt('forwprod',speye(Param.xDim));
	[z, J] = feval(ADfun(fun,Param.zDim), x, Param, options);
end

% get first derivatives using reverse mode
function [z,J] = jacobian_rev(fun,x,Param)
	[z,J] = revprod(fun,x,speye(Param.zDim),Param);
end

function [z,g,H] = hessian_ad(fun,x,Param)
	[z,g,H] = feval(ADfun(fun,Param.zDim), x, Param);
end