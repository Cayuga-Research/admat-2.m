% test functions that have only one operation
% single operation functions aim to test each overloaded opeartion separately
function functions = functions_with_exact_derivatives()
	rng(7);
	functions(1,:) = {rand(5,1),@dot_square,@dot_square_J,[]};
	functions(end+1,:) = {rand(5,1),@squared_norm,@squared_norm_g,@squared_norm_H};
	functions(end+1,:) = {rand(5,1),@(x,Param) quadratic(x,Param,0),@(x,Param) quadratic(x,Param,1), @(x,Param) quadratic(x,Param,2)};
	functions(end+1,:) = {rand(2,1),@(x,Param) rast2009(x,Param,0),@(x,Param) rast2009(x,Param,1), @(x,Param) rast2009(x,Param,2)};
	functions(end+1,:) = {rand(4,1),@(x,Param) pwq(x,Param,0),@(x,Param) pwq(x,Param,1), @(x,Param) pwq(x,Param,2)};
	functions(end+1,:) = {rand(2,1),@(x,Param) griewank(x,Param,0),@(x,Param) griewank(x,Param,1), @(x,Param) griewank(x,Param,2)};
	functions(end+1,:) = {rand(2,1),@(x,Param) michalewic2009(x,Param,0),@(x,Param) michalewic2009(x,Param,1), @(x,Param) michalewic2009(x,Param,2)};
	functions(end+1,:) = {rand(21,1),@lennard,@(x,Param) lennard_d(x,Param,1), @(x,Param) lennard_d(x,Param,2)};
end

%% test cases are separated by comments below
%%
function z = dot_square(x, Param)
	z = x.^2;
end
function J = dot_square_J(x, Param)
	J = diag(2*x);
end

%%
function z = squared_norm(x, Param)
	z = x'*x;
end
function g = squared_norm_g(x, Param)
	g = 2*x';
end
function H = squared_norm_H(x, Param)
	H = diag(2*ones(numel(x),1));
end

%% quadratic function
function f = quadratic(x, Param, derivative)
	H = [0.0087	0.7302	0.1976   -0.0171	0.1412;
		0.7302   -1.3899   -0.1852	0.2387   -0.2159;
		0.1976   -0.1852   -0.2844   -0.4450   -0.4327;
	   -0.0171	0.2387   -0.4450   -0.1294   -0.4454;
		0.1412   -0.2159   -0.4327   -0.4454   -0.2316];

	c = [1.4384;
		0.3252;
	   -0.7549;
		1.3703;
	   -1.7115];

	if 0 == derivative
		f = c'*x + 1/2*x'*H*x;
	elseif 1 == derivative
		f = c' + x'*H;  % gradient
	else
		f = H; % hessian
	end
end

%%
function f = rast2009(x, Param, derivative)
% 
% Rastrigin function
% Matlab Code by A. Hedar (Nov. 23, 2005).
% The number of variables n should be adjusted below.
% The default value of n = 2.
% 
	if 0 == derivative
		f = 20+(x(1).^2-10.*cos(2.*pi.*x(1)))+(x(2).^2-10.*cos(2.*pi.*x(2)))+30;
	elseif 1 == derivative
		f(1,1) = 2.*x(1) + 20.*pi.*sin(2.*pi.*x(1));
		f(1,2) = 2.*x(2) + 20.*pi.*sin(2.*pi.*x(2));
	else
		f(1,1) = 40.*pi.^2.*cos(2.*pi.*x(1)) + 2;
		f(2,1) = 0;
		f(1,2) = f(2,1);
		f(2,2) = 40.*pi.^2.*cos(2.*pi.*x(2)) + 2;
	end
end

%%
function f = pwq(x, Param, derivative)
	if 0 == derivative
		f= 121*x(1).^4+5*(x(3)-x(4)).^2+(x(2)-2*x(3)).^4+10*(x(1)-x(4)).^4;
	elseif 1 == derivative
		g(1,1) = 40*(x(1) - x(4)).^3 + 484*x(1).^3;
		g(1,2) = 4*(x(2) - 2*x(3)).^3;
		g(1,3) = 10*x(3) - 10*x(4) - 8*(x(2) - 2*x(3)).^3;
		g(1,4) = 10*x(4) - 10*x(3) - 40*(x(1) - x(4)).^3;
		f = g;
	else
		H(1,1) = 120*(x(1) - x(4)).^2 + 1452*x(1).^2;
		H(1,4) = -120*(x(1) - x(4)).^2; H(4,1) = H(1,4);
		H(2,2) = 12*(x(2) - 2*x(3)).^2;
		H(2,3) = -2*H(2,2); H(3,2) = H(2,3);
		H(3,3) = 48*(x(2) - 2*x(3)).^2 + 10;
		H(3,4) = -10; H(4,3) = H(3,4);
		H(4,4) = 120*(x(1) - x(4)).^2 + 10;
		f = H;
	end
end


%% Griewank
function f = griewank(x, Param, derivative)
	if 0 == derivative
		c = cos(x(1)).*cos(x(2)./sqrt(2));
		f = (1 + x(1).*x(1)./200 + x(2).*x(2)./200 - c)+1/3*0.14^2*(1/100+c);
	elseif 1 == derivative % gradient
		f(1,1) = x(1)./100 + (1-1/3*0.14^2)*sin(x(1)).*cos(x(2)./sqrt(2));
		f(1,2) = x(2)./100 + (1-1/3*0.14^2)/sqrt(2)*cos(x(1)).*sin(x(2)./sqrt(2));
	else % hessian
		f(1,1) = 1./100 + (1-1/3*0.14^2)*cos(x(1)).*cos(x(2)./sqrt(2));
		f(1,2) = -(1-1/3*0.14^2)*sin(x(1))/sqrt(2).*sin(x(2)./sqrt(2));
		f(2,1) = f(1,2);
		f(2,2) = 1./100 + (1-1/3*0.14^2)/2*cos(x(1)).*cos(x(2)./sqrt(2));
	end
end

%%
function [f, g, H] = michalewic2009(x, Param, derivative)
	if 0 == derivative
		f = -(sin(x(1)).*(sin(x(1).^2./pi)).^2+sin(x(2)).*(sin(2.*x(2).^2./pi)).^2);
	elseif 1 == derivative
		g(1,1) = - cos(x(1)).*sin(x(1).^2./pi).^2 - (4.*x(1).*cos(x(1).^2./pi).*sin(x(1)).*sin(x(1).^2./pi))./pi;
		g(1,2) = - cos(x(2)).*sin((2.*x(2).^2)./pi).^2 - (8.*x(2).*cos((2.*x(2).^2)./pi).*sin(x(2)).*sin((2.*x(2).^2)./pi))./pi;
		f = g;
	else
		H(1,1) = sin(x(1).^2./pi).^2.*sin(x(1)) - (8.*x(1).^2.*cos(x(1).^2./pi).^2.*sin(x(1)))./pi.^2 + (8.*x(1).^2.*sin(x(1).^2./pi).^2.*sin(x(1)))./pi.^2 - (4.*cos(x(1).^2./pi).*sin(x(1).^2./pi).*sin(x(1)))./pi - (8.*x(1).*cos(x(1).^2./pi).*sin(x(1).^2./pi).*cos(x(1)))./pi;
		H(2,1) = 0;
		H(1,2) = H(2,1);
		H(2,2) = sin((2.*x(2).^2)./pi).^2.*sin(x(2)) - (32.*x(2).^2.*cos((2.*x(2).^2)./pi).^2.*sin(x(2)))./pi.^2 + (32.*x(2).^2.*sin((2.*x(2).^2)./pi).^2.*sin(x(2)))./pi.^2 - (8.*cos((2.*x(2).^2)./pi).*sin((2.*x(2).^2)./pi).*sin(x(2)))./pi - (16.*x(2).*cos((2.*x(2).^2)./pi).*sin((2.*x(2).^2)./pi).*cos(x(2)))./pi;
		f = H;
	end
end

%% Lennard-Jones potential function for molecule structure determination in 3-D
function z = lennard(x, Param)
% (i) fix atom 1 to prevent translation
% (ii) place atom 2 on x axis
% (iii) place atom 3 in x-y plane
% the above 3 amount to xx(1) = 0, yy(1) = 0, zz(1) = 0
%								  yy(2) = 0, zz(2) = 0
%											 zz(3) = 0
% set up coordinates of all atoms from x
% for each variable, _d(1:lenx) indicates derivative wrt x
% _dd(1:lenx,1:lenx) indicates second derivative wrt x
% since second derivatives of xx, yy, zz wrt x are zero=, they are not stored
	lenx=length(x);

	natoms = lenx./3 + 2;
	xx = cons(zeros(natoms,1),x);
	yy = cons(zeros(natoms,1),x);
	zz = cons(zeros(natoms,1),x);

	xx(1) = 0;  
	xx(2) = x(1);		
	xx(3) = x(2);
	yy(1) = 0;  zz(1) = 0;
				yy(2) = 0;  zz(2) = 0;
							zz(3) = 0;
	yy(3) = x(3);	   
	count = 4;

	for i=4:3:lenx-2
		xx(count) = x(i);	   
		yy(count) = x(i+1);	
		zz(count) = x(i+2);	 
		count = count + 1;
	end

	% objective function is sum of pairwise potentials
	z = cons(0,x);
	for i=1:natoms-1   %%% check your end value of the loop!!! It causes error when you set it to naroms.
		 for j=i+1:1:natoms
			% d2 is the square of the Euclidean distance between atoms i and j
			d2 = (xx(i)-xx(j)).^2 + (yy(i)-yy(j)).^2 + (zz(i)-zz(j)).^2;

			z = z + 1./d2.^6 - 2./d2.^3;
		 end
	end
end
function d = lennard_d(x,Param,derivative)
	lenx = length(x);

	natoms = lenx./3 + 2;
	n2 = 2.*natoms;
	n3 = 3.*natoms;

	ind = zeros(lenx,1);
	xx = zeros(natoms,1);
	yy = zeros(natoms,1);
	zz = zeros(natoms,1);

	xx(1) = 0;  yy(1) = 0;  zz(1) = 0;
				yy(2) = 0;  zz(2) = 0;
							zz(3) = 0;
	xx(2) = x(1);		ind(1) = 2;
	xx(3) = x(2);		ind(2) = 3;
	yy(3) = x(3);		ind(3) = natoms + 3;
	count = 4;
	for i=4:3:lenx-2
		xx(count) = x(i);	   ind(i) = count;
		yy(count) = x(i+1);	 ind(i+1) = natoms + count;
		zz(count) = x(i+2);	 ind(i+2) = 2.*natoms + count;
		count = count + 1;
	end

	% objective function is sum of pairwise potentials
	f = 0;
	for i=1:natoms-1
		for j=i+1:natoms
			% d2 is the square of the Euclidean distance between atoms i and j
			d2 = (xx(i)-xx(j)).^2 + (yy(i)-yy(j)).^2 + (zz(i)-zz(j)).^2;
			f = f + 1./d2.^6 - 2./d2.^3;
		end
	end
	
	if 1 == derivative
		f_d = zeros(n3,1);			  % derivs wrt xx, yy, and then zz
		for i=1:natoms-1
			for j=i+1:natoms
				% d2 is the square of the Euclidean distance between atoms i and j
				d2 = (xx(i)-xx(j)).^2 + (yy(i)-yy(j)).^2 + (zz(i)-zz(j)).^2;
				dd = -6.*d2.^(-7) + 6.*d2.^(-4);

				% subscripts for repeated use
				ix = i;			 jx = j;				% for xx(1:natoms)
				iy = natoms + i;	jy = natoms + j;	   % for yy(1:natoms)
				iz = n2 + i;		jz = n2 + j;		   % for zz(1:natoms)

				% gradient wrt xx, yy, zz
				f_d(ix) = f_d(ix) + dd.*2.*(xx(i) - xx(j));
				f_d(jx) = f_d(jx) - dd.*2.*(xx(i) - xx(j));
				f_d(iy) = f_d(iy) + dd.*2.*(yy(i) - yy(j));
				f_d(jy) = f_d(jy) - dd.*2.*(yy(i) - yy(j));
				f_d(iz) = f_d(iz) + dd.*2.*(zz(i) - zz(j));
				f_d(jz) = f_d(jz) - dd.*2.*(zz(i) - zz(j));
			end
		end
		d = f_d(ind)';
	else
		f_dd = zeros(n3, n3);
		for i=1:natoms-1
			for j=i+1:natoms
				% d2 is the square of the Euclidean distance between atoms i and j
				d2 = (xx(i)-xx(j)).^2 + (yy(i)-yy(j)).^2 + (zz(i)-zz(j)).^2;

				% subscripts for repeated use

				ix = i;			 jx = j;				% for xx(1:natoms)
				iy = natoms + i;	jy = natoms + j;	   % for yy(1:natoms)
				iz = n2 + i;		jz = n2 + j;		   % for zz(1:natoms)

				% Hessian - again, xx, yy, zz in that order

				t1 = 42.*d2.^(-8) - 24.*d2.^(-5);
				t2 = -6.*d2.^(-7) + 6.*d2.^(-4);
				dxi = 2.*(xx(i)-xx(j));	dxj = -dxi;
				dyi = 2.*(yy(i)-yy(j));	dyj = -dyi;
				dzi = 2.*(zz(i)-zz(j));	dzj = -dzi;

				f_dd(ix,ix) = f_dd(ix,ix) + t1.*dxi.*dxi + t2.*2;
				f_dd(jx,jx) = f_dd(jx,jx) + t1.*dxj.*dxj + t2.*2;
				f_dd(ix,jx) = f_dd(ix,jx) + t1.*dxi.*dxj + -t2.*2;

				f_dd(iy,iy) = f_dd(iy,iy) + t1.*dyi.*dyi + t2.*2;
				f_dd(jy,jy) = f_dd(jy,jy) + t1.*dyj.*dyj + t2.*2;
				f_dd(iy,jy) = f_dd(iy,jy) + t1.*dyi.*dyj + -t2.*2;

				f_dd(iz,iz) = f_dd(iz,iz) + t1.*dzi.*dzi + t2.*2;
				f_dd(jz,jz) = f_dd(jz,jz) + t1.*dzj.*dzj + t2.*2;
				f_dd(iz,jz) = f_dd(iz,jz) + t1.*dzi.*dzj + -t2.*2;

				% now the cross terms between x, y, z

				f_dd(ix,iy) = f_dd(ix,iy) + t1.*dxi.*dyi;
				f_dd(ix,jy) = f_dd(ix,jy) + t1.*dxi.*dyj;
				f_dd(ix,iz) = f_dd(ix,iz) + t1.*dxi.*dzi;
				f_dd(ix,jz) = f_dd(ix,jz) + t1.*dxi.*dzj;

				f_dd(jx,iy) = f_dd(jx,iy) + t1.*dxj.*dyi;
				f_dd(jx,jy) = f_dd(jx,jy) + t1.*dxj.*dyj;
				f_dd(jx,iz) = f_dd(jx,iz) + t1.*dxj.*dzi;
				f_dd(jx,jz) = f_dd(jx,jz) + t1.*dxj.*dzj;

				f_dd(iy,iz) = f_dd(iy,iz) + t1.*dyi.*dzi;
				f_dd(iy,jz) = f_dd(iy,jz) + t1.*dyi.*dzj;

				f_dd(jy,iz) = f_dd(jy,iz) + t1.*dyj.*dzi;
				f_dd(jy,jz) = f_dd(jy,jz) + t1.*dyj.*dzj;
			end
		end

		f_dd = f_dd + triu(f_dd, 1)';	 % make H symmetric - only upper tr known
		d = f_dd(ind, ind);
	end
end