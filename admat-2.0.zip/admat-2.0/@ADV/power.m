function y = power(x,b)
    assert(~isa(b,'ADV'))
    y = x.val.^b;
    % ADMAT_CPP('emplace','square',y.val,y.ofs,x.val,x.ofs)
end