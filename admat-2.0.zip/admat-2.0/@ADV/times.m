function y = times(a,b)
    y = ADV(getval(a).*getval(b),'times',a,b);
end