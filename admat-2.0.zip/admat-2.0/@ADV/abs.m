function y = abs(x)
    y = ADV(abs(x.val),'abs',x);
end