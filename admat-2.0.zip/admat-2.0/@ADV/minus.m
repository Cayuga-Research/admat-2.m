% currently only supports vector-vector minus
function z = minus(x,y)
    z = ADV(getval(x)-getval(y),'minus',x,y);
end