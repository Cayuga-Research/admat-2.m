% get value of ADV
function y = getval(x)
    y = x.val;
end