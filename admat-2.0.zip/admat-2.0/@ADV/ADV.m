%% create ADV struct
% x - non-ADV value
% op - operation that produced value x, can be empty
% op1 - operand1 of the operation, must present if op is non-empty
% op2 - operand2 of the operation, must present if op is binary
% X.val - value of the vector
% X.ofs - offset on the tape
function X = ADV(x,op,op1,op2)
    switch nargin
        case 1  % independent operation
            X.ofs = ADMAT_CPP('emplace',x);
        case 3  % unitary operation
            assert(isa(op1,'ADV'),'unitary operator should be overloaded only for ADV type')
            X.ofs = ADMAT_CPP('emplace',x,op,op1.ofs);
        case 4  % binary operation
            if isa(op1,'ADV') 
                op1 = op1.ofs;
            else % register const if needed
                op1 = ADMAT_CPP('emplace',op1,'const');
            end
            if isa(op2,'ADV') 
                op2 = op2.ofs;
            else % register const if needed
                op2 = ADMAT_CPP('emplace',op2,'const');
            end
            X.ofs = ADMAT_CPP('emplace',x,op,op1,op2);
        otherwise
            error('invalid ADV usage');
    end
    X.val = x;
    X = class(X,'ADV');
end