% currently only support vector, which doesn't need tape registration
function x = ctranspose(x)
    x.val = x.val';
end