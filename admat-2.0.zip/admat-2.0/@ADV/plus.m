% currently only supports vector-vector plus
function z = plus(x,y)
    z = ADV(getval(x)+getval(y),'plus',x,y);
end