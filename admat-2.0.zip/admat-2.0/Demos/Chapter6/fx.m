function y = fx(x, Extra)
% 
% right hand side of the Euler method
%

y = x;