cd Chapter3
DemoCons
DemoFeval
DemoGrad
DemoHess
DemoJac
cd ..

cd Chapter4
DemoSprHess
DemoSprJac
cd ..

cd Chapter5
Demo2nd1
Demo2nd2
DemoFwd1
DemoFwd2
DemoInter1
DemoRvs1
DemoRvs2
DemoSP
DemoStct
DemoStorage
cd ..

cd Chapter6
DemoExpHess
DemoNewton
DemoNewton_Exp
DemoRawExp
cd ..

cd Chapter7
DemoFmincon
DemoFminunc
DemoLSq
cd ..

cd Gradient
DemoStct
cd ..

cd Sensitivity
DemoSens
cd ..

cd Appendix
DemoQNFminunc
DemoSens
cd ..