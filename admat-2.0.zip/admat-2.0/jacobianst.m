%{

  structured jacobian computation

  requires: ADMAT 2.0, MATLAB 2016b or later

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 

  Wanqi Li
  wanqi@outlook.com
  
  2017-04-27

%}
function [z, WJ] = jacobianst(CG, x, Param)

func = CG.func;
num_func = size(func,1);
assert( 1 == size(func,2), 'functions must be a column cell of function handles');

dep = CG.dep;
assert( num_func == size(dep,1), 'dependency of every function must be specified');

[x_rdim, x_cdim] = size(x);
assert( 1 == x_cdim, 'input x must be a column vector');

Y = cell(num_func,1);

for n = 1:num_func
    
  input = [ x(1:end*dep{n,1}); cell2mat(Y(dep{n,2})) ];

  Y{n} = feval(func{n}, input, Param);
    
end

z = Y{end};

if isfield(Param,'W')
    
  W = Param.W;
  assert( size(W,1) == size(z,1), 'output dimension should equal size(W,1)');
    
else

  W = speye(numel(z));
    
end

WJ = zeros(size(W,1),x_rdim);

G = cell(num_func,1);

G{num_func} = W;

for n = num_func:-1:1

  input = [x(1:end*dep{n,1}); cell2mat(Y(dep{n,2}))];

  AD_fun = ADfun(func{n},size(Y{n},1));

  options = setopt('revprod',G{n});

  [~, w] = feval(AD_fun, input, Param, options);

  head = 1;
  if dep{n,1}

    WJ = WJ + w(:,1:x_rdim);

    head = head + x_rdim;
  end

  for k = dep{n,2}

    tail = head + size(Y{k},1) - 1;

    if isempty(G{k})

      G{k} = w(:,head:tail);

    else

      G{k} = G{k} + w(:,head:tail);

    end

    head = tail + 1;
  end
    
end