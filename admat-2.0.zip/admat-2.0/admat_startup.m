%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%  startup.m for ADMAT 2.0
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% add paths manually.
% ADMAT=pwd;
% 
% path(path,ADMAT);
% path(path, strcat(ADMAT, '/privfun'));
% path(path, strcat(ADMAT, '/reverse'));
% path(path, strcat(ADMAT, '/reverses'));
% path(path, strcat(ADMAT, '/admit-2'));
% path(path, strcat(ADMAT, '/Newton'));
% path(path, strcat(ADMAT, '/Interpolation'));
% path(path, strcat(ADMAT, '/Demos'));
% 
% clear ADMAT

% initialize the global variables
initialglobals
