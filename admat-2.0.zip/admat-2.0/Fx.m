function z = Fx(x)
n = length(x);
z = zeros(n,1);
z(1)= 3*x(1)+2*x(2);
z(2)= 5*x(1)^2+4*x(1)+x(2);