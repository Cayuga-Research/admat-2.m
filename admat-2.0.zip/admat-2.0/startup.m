fprintf('ADMAT-2 loaded\n')
initialglobals